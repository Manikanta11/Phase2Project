package com.teacherslist;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table

public class Student {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int id;
	private String studentname;
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cid")
	private Classes classes;
	
	public Student() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public Student(String studentname) {
		super();
		this.studentname = studentname;
	}

	@Override
	public String toString() {
		return "Students [id=" + id + ", studentname=" + studentname + "]";
	}
	
	
	
}