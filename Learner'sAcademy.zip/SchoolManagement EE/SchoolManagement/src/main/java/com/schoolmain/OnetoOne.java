package com.schoolmain;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.teacherslist.Classes;
import com.teacherslist.Student;


public class OnetoOne {

	public static void main(String[] args) {
		
		Configuration configuration = new Configuration().configure();
		StandardServiceRegistryBuilder builder= new StandardServiceRegistryBuilder()
			
				.applySettings(configuration.getProperties());
		SessionFactory factory=configuration.buildSessionFactory(builder.build());
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Student s1= new Student("Bhishma");
		Student s2= new Student("Manikanta");

		s1.setId(1);

		Classes c1= new Classes("classA", s1);
		c1.setId(2);
		
		session.save(s1);
		session.save(s2);
		session.save(c1);
		
		transaction.commit();
		session.close();
		factory.close();
	}

}